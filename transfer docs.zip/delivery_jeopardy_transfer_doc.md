# Delivery Jeopardy — Transfer Doc

## What this is
A two-team, Jeopardy-style classroom game built as a single self-contained HTML file (`jeopardy_game.html`). Students read/perform short prompts (e.g. "Fake Apologies for $300") with delivery directions attached.

## Current status: **working and live**
- Embedded on the company Squarespace site via an iframe.
- **Important:** Google Drive does NOT work for hosting this — it serves the HTML as raw text instead of executing it. The working live version is hosted on **Netlify** at:
  `https://sweet-pie-f5ad8e.netlify.app/jeopardy_game.html`
- Squarespace embed uses an **Embed block** (not a Code block) with:
  ```html
  <iframe src="https://sweet-pie-f5ad8e.netlify.app/jeopardy_game.html"
          width="100%" height="900px" frameborder="0" style="border:none;">
  </iframe>
  ```
- The user confirmed the background/styling displays correctly once loaded this way.

## How to update the live game
1. Get the latest `jeopardy_game.html` from this chat/Claude.
2. Go to https://app.netlify.com/drop and drag the new file onto the page (no login needed).
3. This generates a **new random URL** each time (e.g. `https://xyz-123.netlify.app`).
4. Update the `src` in the Squarespace iframe to the new URL.
5. **Known friction point:** every drag-and-drop to Netlify Drop creates a new URL, so the Squarespace embed must be updated each time. The user is aware and has deferred a more permanent solution (e.g. GitHub Pages with a stable URL, or a proper Netlify account with a fixed site name) to a future session — not urgent for now.

## Things that were tried and don't work
- **Pasting HTML directly into a Squarespace Code Block** — Squarespace's own CSS overrides styles (caused the "white background" bug that took a long time to diagnose) and it may strip/limit JavaScript.
- **Google Drive preview embed** — renders as plain text, not executable HTML.
- **GitHub Pages** — works in principle, but the repo (`https://github.com/joey718/delivery-jeopardy`) had the README showing instead of the game; needs the HTML file renamed to `index.html` OR the URL needs the explicit filename appended (`/jeopardy_game.html`). Left as a "future draft" — Netlify Drop is the current working solution.

## Data structure / customization
- Category and prompt data is **hardcoded** into a JS object called `allCategories` in the HTML (not live-synced from Google Sheets — a live CSV fetch was attempted but blocked by CORS restrictions on Google Sheets).
- Source spreadsheet for content: columns B–K of the [prompts sheet](https://docs.google.com/spreadsheets/d/1AzvZqJGwkJREuRHM7yKy2D1fxSIJVx9t6dSzzPHeaRY/edit) — categories in row 1, prompts in rows 2–11, money values in column A. Columns M–Z hold additional/alternate categories.
- Currently loaded categories in the file: INSPIRATIONAL, APOLOGIES, CONGRESS VIBES (renamed from "Generic Congress Speeches"), TOASTS, SCRIMMAGE SPEECHES, IRL POLITICIANS, MOVIES & TV.
- **To update content:** edit the `allCategories` object directly in the HTML (around line 596 in the current file) and re-upload to Netlify. There is no live sync — any spreadsheet edits must be manually copied into the code.
- In-app "Change Categories" button lets the user pick any 5 of the available categories to use in a given game session (this is separate from adding brand-new categories, which requires editing the code).

## Feature list (all implemented and confirmed working)
- Title: "DELIVERY JEOPARDY!"
- Purple gradient background (`#667eea` → `#764ba2`)
- 5x10 game board, equal-width category columns, category text wraps within its box
- Click a cell → full-screen "teleprompter" modal: large prompt text, smaller directions text, minimal header/vertical clutter, preserves line breaks from source text
- Team score tracking; buttons read "Points for Team 1" / "Points for Team 2"; Team 2's name/score right-aligned
- Student name entry (textarea, one name per line) per team
- "Pick Random Student" button per team — selects without removing from the list
- Judges panel + "Select 2 Judges" button — randomly picks one student from each team and **removes** them from their team list, adding them to the judges list
- Extra vertical spacing added: after Reset/Change Categories buttons, and before the judges section
- "Reset Game" and "Change Categories" controls
- Progress (scores, used cells) persists via localStorage with a version check that auto-resets if the data structure changes (prevents stale-cache bugs)

## Suggested next steps (not yet started)
- Set up a stable hosting URL (GitHub Pages done right, or a named Netlify site/account) so updates don't require re-pasting a new iframe URL into Squarespace each time.
- Decide whether to revisit live Google Sheets sync (would require either publishing the sheet to web as CSV, or a Sheets API key) vs. continuing to hand-edit the hardcoded data.

## File
The current working file is attached: `jeopardy_game.html`
